# Historical Phase-21 Forensic Package
Built for independent audit by a third-party agent (Freebuff).
Package assembled: 2026-09-26, in the same session/environment that
generated the original benchmark.

## 1. What this package claims, precisely

**CLAIM:** Running `source/phase21.py`, unmodified, against
`data/eurusd_d.csv`, unmodified, under the environment in
`requirements.txt`, reproduces:

```
EUR/USD: 115 trades, PF 1.49, total R +32.26, max DD ≈ -12.00R
  train:      78 trades, +24.26R
  validation: 14 trades, -2.00R
  final:      23 trades, +10.00R, PF 1.83
```

**THIS IS BOTH THE EXPECTED RESULT AND AN ACTUALLY-OBSERVED RESULT** — I
re-ran `phase21.py` fresh, specifically to build this package (not
recalled from memory), and it produced this exact output. See
`REPRODUCE.md` for the literal console output and command. That said, "I
re-ran it in my own session" is not independent verification — that is
exactly what this package exists to let Freebuff do separately.

## 2. Repository / commit

This code was previously committed to a git repository in this same
session:
- Commit: `556f9cf52ea055fdce1defcc8b79959fb1941094`
- Commit message: "Full research log: Phases 14-26 (strategy search,
  robustness, cross-pair, walk-forward, statistical stress test)"
- Note: I do not have push/network access to any remote in this
  environment, so I cannot tell you this commit exists on GitHub or
  anywhere externally reachable — only that it exists in a local `.git`
  history I built and (in an earlier turn) gave you as a downloadable
  bundle/tarball. If you have that bundle, this same commit hash should
  be present in it — that's a checkable cross-reference.

## 3. File-by-file provenance

| File | Status | Notes |
|---|---|---|
| `source/phase14.py` | **ORIGINAL SOURCE** | Core engine: `load_daily`, `ema`, `atr`, `simulate_trades`, `split_trades`, `compute_stats`, `max_losing_streak`. Byte-identical to the working copy (verified via `diff`). |
| `source/phase20.py` | **ORIGINAL SOURCE** | Not required to reproduce the EUR/USD Phase-21 benchmark itself. Included because it was requested. Defines `adx14()`, which `phase24.py` imports. Has executable top-level code (see REPRODUCE.md side-effects note). |
| `source/phase21.py` | **ORIGINAL SOURCE** | **This is the file that directly generates the claimed benchmark.** |
| `source/phase23.py` | **ORIGINAL SOURCE** | Cross-pair runner; imports `phase21.py`'s weekly-filter functions. Not needed for the EUR/USD-only benchmark, included because requested. |
| `source/phase24.py` | **ORIGINAL SOURCE — NOT ON YOUR REQUESTED LIST, BUT A HARD DEPENDENCY** | `phase25.py` does `from phase24 import PAIRS, build_pair`. Without this file, `phase25.py` cannot run at all. Added for completeness; flagging clearly since you didn't ask for it by name. |
| `source/phase25.py` | **ORIGINAL SOURCE** | Walk-forward runner. Depends on `phase24.py` (above) and `phase14.py`. |
| `data/eurusd_d.csv` | **ORIGINAL DATA** | Exact file used. Full file: 14,270 rows, 1971-01-04 to 2026-09-25, columns `Date,Open,High,Low,Close`. `phase21.py` internally filters this to `>=2003-12-01` at load time (`load_daily(FILE, "2003-12-01")`) — the filtered subset actually used by the strategy is 5,914 rows, 2003-12-01 to 2026-09-25. Both the raw file and the filtering logic are included; nothing is pre-filtered in this package. |
| `output/phase21_trades_ledger.csv` | **ACTUALLY-OBSERVED OUTPUT** | The complete 115-row trade ledger this exact run produced (columns: signal_date, entry_date, exit_date, entry_price, stop_price, target_price, exit_price, atr_at_signal, outcome, r_multiple, split). This is a result artifact, not source — provided so Freebuff can diff their own reproduction's ledger against this one row-for-row, not just compare summary stats. |
| `requirements.txt` | **ORIGINAL ENVIRONMENT** | Captured directly via `python3 --version` / `pip freeze` in the exact session that ran the benchmark. |
| `REPRODUCE.md` | **NEWLY WRITTEN (this session)** | Instructions, not strategy code. Written by me now, for this package. Not part of the "historical" artifact — it's packaging documentation. |
| `HASHES.txt` | **NEWLY GENERATED (this session)** | SHA-256 of every file in this package, generated at packaging time. |

**Nothing in this package is RECONSTRUCTED or INFERRED.** Every `.py` and `.csv` file is a direct, unmodified copy of a file that already existed in the working environment before this packaging request — verified byte-identical via `diff` at copy time (see terminal output this was built from). I did not rewrite, "clean up," or reconstruct any strategy logic to build this package.

## 4. What is explicitly UNAVAILABLE — NOT RECOVERED

- **`gbpusd_d.csv`, `usdjpy_d.csv`, `audusd_d.csv`** — needed to reproduce Phase 23/25's cross-pair numbers, not the EUR/USD number you asked about specifically. Not included because you only asked for the EUR/USD forensic package; can be added on request.
- **Any "V1–V13" strategy specification** — as established in the prior message in this conversation, no such artifact exists anywhere in my accessible context. Not included because it does not exist here, not because it was omitted.
- **A remote/pushed copy of the git commit** — I have no outbound network access in this environment and cannot confirm this commit exists anywhere outside the local repo I built for you.
- **`phase15_reconciliation.py`, `phase22.py`, `phase26_part1.py`, `phase26_part2.py`** — not requested, not included, but they exist in the same working directory if needed (they are not part of the EUR/USD Phase-21 reproduction path).

## 5. Integrity — SHA-256 (see `HASHES.txt` for the canonical copy)

```
e8c82beeca1a4a0a257aaddeb526715a7f3e759b362d56669c10ff077f1987c0  source/phase14.py
cfac42f0b955320ab04cf87f2fb99e8d73475b0b67d9a269e2a7696cbb0f2b64  source/phase20.py
5408d8eec91a13fc95262845f2620ace850685c36f2e6218ceaa00176394d478  source/phase21.py
a8d04d8a90df54de113745cd985c0d7365b20554e1158cf8630aa9cf599a0689  source/phase23.py
b808cc276d22c4a40e034cf741902f079712e760401515718182246ebb6ba470  source/phase24.py
aab17c577c6c6ebcc51e6cc951b48b8bd3998cb3b4bc753a227b111bf11ec95e  source/phase25.py
e0676d9232c87be36aed5db2317b0c80f3838b5e9d517afb319f092aa8fd0d52  data/eurusd_d.csv
30d22be417fbdd0d3db011bce4b0ac2f785f088d30a8dc10900905e7ae2f70d0  output/phase21_trades_ledger.csv
```

## 6. The one question Freebuff needs to answer

> "Can the historical implementation actually reproduce 115 trades / PF 1.49 / +32.26R?"

To answer this independently: run `source/phase21.py` per `REPRODUCE.md`
against `data/eurusd_d.csv`, and diff the resulting trade set against
`output/phase21_trades_ledger.csv`. If Freebuff's environment produces a
byte-different or numerically-different ledger, the discrepancy itself
(which trades differ, and how) is more diagnostic than the summary
stats alone — that's why the full ledger, not just the headline numbers,
is included.

## 7. Explicit disclosure of a limitation in this package itself

I generated this entire package — including the "independent" re-run
used to confirm the benchmark — in the same environment and same session
that produced the original numbers. That is **not** independent
verification. It confirms internal consistency (the code deterministically
reproduces its own claimed output right now, in this environment), not
correctness or absence of bugs, and not that the result would hold on
data or an environment outside this one. That gap is exactly what handing
this package to Freebuff is meant to close.
