# Exact reproduction steps

## Environment
- Python 3.12.3
- pandas 3.0.2
- numpy 2.4.4
(see requirements.txt)

## Directory setup
Freebuff must place files exactly like this before running anything,
because phase21.py hardcodes an absolute path to the data file:

```
<workdir>/
  phase21.py            (from source/)
  phase14.py             (from source/)   <- imported by phase21.py
```

AND the data file must be placed at this EXACT absolute path, because
phase21.py does not take the path as an argument — it is hardcoded:

```
/mnt/user-data/uploads/eurusd_d.csv    <- copy data/eurusd_d.csv here
```

If Freebuff's environment cannot write to that exact path, the two
lines in phase21.py that must be changed (and ONLY these two, as a
necessary porting step, not a strategy change) are:

```python
FILE = "/mnt/user-data/uploads/eurusd_d.csv"
```

## Command
```bash
cd <workdir>
python3 phase21.py
```

## Expected console output (the benchmark line)
```
OVERALL: trades=115 win_rate=42.6% PF=1.49 totalR=32.26 avgR=0.281 maxDD=-12.00 worstStreak=7
  train      trades=  78 win_rate=43.6% PF=1.55 totalR=24.26
  validation trades=  14 win_rate=28.6% PF=0.80 totalR=-2.00
  final      trades=  23 win_rate=47.8% PF=1.83 totalR=10.00
```

This exact output was captured on a fresh re-run performed specifically
to build this package (2026-09-26, same session, same environment) and
matched the previously reported numbers exactly — this is not a
transcription from memory, it is a live-verified re-run.

## To reproduce the cross-pair benchmark (Phase 23)
Also requires phase21.py (imported for its weekly-filter functions) and
the three other pair CSVs at their own hardcoded paths
(`/mnt/user-data/uploads/gbpusd_d.csv`, `usdjpy_d.csv`, `audusd_d.csv`).
These three CSVs are NOT included in this package (only EUR/USD was
requested) — see README.md, "UNAVAILABLE" section.

## To reproduce the walk-forward benchmark (Phase 25)
Requires phase24.py, which is NOT in your requested file list but IS a
hard dependency (`phase25.py` does `from phase24 import PAIRS, build_pair`).
It has been included in this package under source/ for exactly that
reason — see README.md.

## A note on side effects
phase14.py, phase20.py, phase21.py, and phase24.py all contain executable
top-level code (not just function/class definitions) — importing any of
them from another script re-runs their full body, including their own
print statements and file writes. This is a genuine property of the
original code, not an artifact of packaging it. Freebuff should expect
console output from phase14.py's own Phase-14 run to appear whenever
phase21.py (or anything importing phase14) is executed, because phase21.py
imports directly from phase14.py.
