"""
PHASE 23 — CROSS-PAIR VALIDATION
Exact frozen Phase-21 spec, zero changes, run unchanged on GBP/USD,
USD/JPY, AUD/USD (raw CSVs already available in this environment).
"""

import pandas as pd
import numpy as np
from phase14 import load_daily, ema, atr as atr_func, simulate_trades, split_trades, compute_stats
from phase21 import build_weekly_filter, map_weekly_to_daily

PAIRS = {
    "GBPUSD": {"file": "/mnt/user-data/uploads/gbpusd_d.csv", "pip": 0.0001},
    "USDJPY": {"file": "/mnt/user-data/uploads/usdjpy_d.csv", "pip": 0.01},
    "AUDUSD": {"file": "/mnt/user-data/uploads/audusd_d.csv", "pip": 0.0001},
}
START_DATE = "2003-12-01"
OUT_DIR = "/home/claude/backtest/phase21_results"

print("=== PHASE 23: cross-pair validation of Phase-21 candidate ===\n")

rows = []
for name, cfg in PAIRS.items():
    daily = load_daily(cfg["file"], START_DATE)
    daily["EMA20"] = ema(daily["Close"], 20)
    daily["EMA50"] = ema(daily["Close"], 50)
    daily["EMA50_rising"] = daily["EMA50"] > daily["EMA50"].shift(5)
    daily["ATR"] = atr_func(daily, 14)
    daily["PrevHigh"] = daily["High"].shift(1)

    weekly_ok = build_weekly_filter(daily)
    daily["weekly_ok"] = map_weekly_to_daily(daily, weekly_ok)
    daily["daily_trend_ok"] = (daily["EMA20"] > daily["EMA50"]) & daily["EMA50_rising"]
    daily["pullback"] = (daily["Low"] <= daily["EMA20"]) & (daily["Close"] > daily["EMA20"])
    daily["confirm"] = daily["Close"] > daily["PrevHigh"]
    daily["signal"] = daily["weekly_ok"] & daily["daily_trend_ok"] & daily["pullback"] & daily["confirm"]
    daily.loc[:59, "signal"] = False

    trades_df = simulate_trades(daily, "signal", stop_mult=1.0, target_mult=2.0, friction_pips=1.5, pip=cfg["pip"])
    if len(trades_df) == 0:
        print(f"{name}: NO TRADES.")
        rows.append({"pair": name, "trades": 0})
        continue
    trades_df = split_trades(trades_df, daily)
    trades_df.to_csv(f"{OUT_DIR}/phase23_{name}_trades.csv", index=False)

    overall = compute_stats(trades_df)
    split_stats = {s: compute_stats(trades_df[trades_df["split"] == s]) for s in ["train", "validation", "final"]}

    print(f"--- {name} ---")
    print(f"  OVERALL: trades={overall['trade_count']} win_rate={overall.get('win_rate', float('nan')):.1%} "
          f"PF={overall.get('profit_factor', float('nan')):.2f} totalR={overall.get('total_R', float('nan')):.2f} "
          f"maxDD={overall.get('max_drawdown_R', float('nan')):.2f} worstStreak={overall.get('worst_losing_streak', float('nan'))}")
    for s in ["train", "validation", "final"]:
        st = split_stats[s]
        print(f"    {s:10s} trades={st['trade_count']:>4} win_rate={st.get('win_rate', float('nan')):.1%} "
              f"PF={st.get('profit_factor', float('nan')):.2f} totalR={st.get('total_R', float('nan')):.2f}")
    print()

    rows.append({
        "pair": name, "trades": overall["trade_count"], "win_rate": overall.get("win_rate"),
        "PF": overall.get("profit_factor"), "total_R": overall.get("total_R"),
        "avg_R": overall.get("expectancy_R"), "max_DD_R": overall.get("max_drawdown_R"),
        "worst_streak": overall.get("worst_losing_streak"),
        "train_trades": split_stats["train"]["trade_count"], "train_R": split_stats["train"].get("total_R"),
        "val_trades": split_stats["validation"]["trade_count"], "val_R": split_stats["validation"].get("total_R"),
        "final_trades": split_stats["final"]["trade_count"], "final_R": split_stats["final"].get("total_R"),
        "final_PF": split_stats["final"].get("profit_factor"), "final_win_rate": split_stats["final"].get("win_rate"),
    })

summary = pd.DataFrame(rows)
summary.to_csv(f"{OUT_DIR}/phase23_summary.csv", index=False)
print(summary.to_string(index=False))
