"""
Independent verification of the "regime-conditioned momentum" candidate
described in a handoff document, then unchanged cross-pair test.

I have not previously run this exact strategy in this conversation, so
before trusting any numbers attributed to it, I reproduce it myself on
EUR/USD as a sanity check. Only after that do I run it, completely
unchanged, on GBP/USD, USD/JPY, AUD/USD (all three raw CSVs are actually
available in this environment).

FROZEN RULES (as specified in the handoff doc):
  1. Close > previous 20-day high  (20-day breakout)
  2. ROC10 > 0
  3. ADX14 >= 25
  4. ATR14 between the 33rd and 67th rolling percentile (window: 100 days,
     since that's the window used elsewhere in this research; not stated
     explicitly in the handoff, so this one parameter is my own frozen
     choice, fixed BEFORE looking at any result)
  Execution: next-day open entry, 1.5-pip friction, 1 ATR stop, 2 ATR
  target, gap-aware exits, stop-first-if-both-hit-same-day, long only.
  Split: chronological 70/15/15 by entry date.

PRE-REGISTERED CLASSIFICATION CRITERIA (fixed before viewing any cross-pair
result, per the user's request for descriptive, non-subjective labels):
  - "generalizes"          : train, validation AND final all net positive
                              total R; overall PF >= 1.1; overall trade
                              count >= 30; final-holdout PF >= 1.0
  - "mixed"                 : at least one split positive and one
                              negative/flat, or overall PF in [0.9, 1.1)
  - "fails to generalize"   : overall total R negative, or final-holdout
                              PF < 0.8
  - "insufficient sample"   : overall trade count < 20, or any individual
                              split has < 5 trades (result for that split
                              not meaningfully interpretable)
"""

import pandas as pd
import numpy as np
from phase14 import (
    load_daily, ema, atr as atr_func, simulate_trades, split_trades,
    compute_stats, PIP, OUT_DIR as PHASE14_OUT
)
import os

OUT_DIR = "/home/claude/backtest/phase20_results"
os.makedirs(OUT_DIR, exist_ok=True)

PAIRS = {
    "EURUSD": {"file": "/mnt/user-data/uploads/eurusd_d.csv", "pip": 0.0001},
    "GBPUSD": {"file": "/mnt/user-data/uploads/gbpusd_d.csv", "pip": 0.0001},
    "USDJPY": {"file": "/mnt/user-data/uploads/usdjpy_d.csv", "pip": 0.01},
    "AUDUSD": {"file": "/mnt/user-data/uploads/audusd_d.csv", "pip": 0.0001},
}
START_DATE = "2003-12-01"


def adx14(df, period=14):
    high, low, close = df["High"], df["Low"], df["Close"]
    up_move = high.diff()
    down_move = -low.diff()
    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)
    prev_close = close.shift(1)
    tr = pd.concat([
        high - low, (high - prev_close).abs(), (low - prev_close).abs()
    ], axis=1).max(axis=1)

    atr_w = tr.ewm(alpha=1 / period, adjust=False).mean()
    plus_dm_s = pd.Series(plus_dm, index=df.index).ewm(alpha=1 / period, adjust=False).mean()
    minus_dm_s = pd.Series(minus_dm, index=df.index).ewm(alpha=1 / period, adjust=False).mean()

    plus_di = 100 * (plus_dm_s / atr_w)
    minus_di = 100 * (minus_dm_s / atr_w)
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
    adx = dx.ewm(alpha=1 / period, adjust=False).mean()
    return adx


def build_signal(daily):
    daily["EMA_dummy"] = ema(daily["Close"], 20)  # not used in this strategy, kept for parity
    daily["ATR"] = atr_func(daily, 14)
    daily["ADX14"] = adx14(daily, 14)
    daily["ROC10"] = daily["Close"].pct_change(10)
    daily["High20_prev"] = daily["High"].rolling(20).max().shift(1)
    daily["ATR_pct33_100"] = daily["ATR"].rolling(100).quantile(0.33)
    daily["ATR_pct67_100"] = daily["ATR"].rolling(100).quantile(0.67)

    daily["signal"] = (
        (daily["Close"] > daily["High20_prev"])
        & (daily["ROC10"] > 0)
        & (daily["ADX14"] >= 25)
        & (daily["ATR"] >= daily["ATR_pct33_100"])
        & (daily["ATR"] <= daily["ATR_pct67_100"])
    )
    return daily


def classify(overall_stats, split_stats):
    trade_count = overall_stats.get("trade_count", 0)
    if trade_count < 20 or any(s.get("trade_count", 0) < 5 for s in split_stats.values()):
        return "insufficient sample"
    total_R_by_split = {k: v.get("total_R", 0) for k, v in split_stats.items()}
    pf = overall_stats.get("profit_factor", np.nan)
    final_pf = split_stats["final"].get("profit_factor", np.nan)

    if pd.isna(pf):
        return "insufficient sample"
    if (overall_stats.get("total_R", 0) < 0) or (not pd.isna(final_pf) and final_pf < 0.8):
        return "fails to generalize"
    all_positive = all(v > 0 for v in total_R_by_split.values())
    if all_positive and pf >= 1.1 and trade_count >= 30 and (not pd.isna(final_pf)) and final_pf >= 1.0:
        return "generalizes"
    return "mixed"


results = {}
print("=== Verifying regime-conditioned momentum candidate ===\n")

for name, cfg in PAIRS.items():
    print(f"--- {name} ---")
    daily = load_daily(cfg["file"], START_DATE)
    daily = build_signal(daily)
    warmup = 105  # ATR percentile window (100) + a few bars margin
    daily.loc[: warmup - 1, "signal"] = False

    trades_df = simulate_trades(daily, "signal", stop_mult=1.0, target_mult=2.0,
                                 friction_pips=1.5, pip=cfg["pip"])
    if len(trades_df) == 0:
        print("  NO TRADES generated.\n")
        results[name] = {"trade_count": 0}
        continue

    trades_df = split_trades(trades_df, daily)
    trades_df.to_csv(f"{OUT_DIR}/{name}_regime_momentum_trades.csv", index=False)

    split_stats = {}
    for split_name in ["train", "validation", "final"]:
        sub = trades_df[trades_df["split"] == split_name]
        split_stats[split_name] = compute_stats(sub)

    overall = compute_stats(trades_df)
    label = classify(overall, split_stats)

    results[name] = {
        "trade_count": overall["trade_count"],
        "win_rate": overall.get("win_rate"),
        "profit_factor": overall.get("profit_factor"),
        "total_R": overall.get("total_R"),
        "avg_R_per_trade": overall.get("expectancy_R"),
        "max_drawdown_R": overall.get("max_drawdown_R"),
        "train_trades": split_stats["train"]["trade_count"],
        "train_R": split_stats["train"].get("total_R"),
        "val_trades": split_stats["validation"]["trade_count"],
        "val_R": split_stats["validation"].get("total_R"),
        "final_trades": split_stats["final"]["trade_count"],
        "final_R": split_stats["final"].get("total_R"),
        "final_PF": split_stats["final"].get("profit_factor"),
        "final_win_rate": split_stats["final"].get("win_rate"),
        "classification": label,
    }

    print(f"  trades={overall['trade_count']} win_rate={overall.get('win_rate', float('nan')):.1%} "
          f"PF={overall.get('profit_factor', float('nan')):.2f} totalR={overall.get('total_R', float('nan')):.2f} "
          f"maxDD={overall.get('max_drawdown_R', float('nan')):.2f}")
    print(f"  train: n={split_stats['train']['trade_count']} R={split_stats['train'].get('total_R', float('nan')):.2f} | "
          f"val: n={split_stats['validation']['trade_count']} R={split_stats['validation'].get('total_R', float('nan')):.2f} | "
          f"final: n={split_stats['final']['trade_count']} R={split_stats['final'].get('total_R', float('nan')):.2f} "
          f"PF={split_stats['final'].get('profit_factor', float('nan')):.2f} winrate={split_stats['final'].get('win_rate', float('nan')):.1%}")
    print(f"  CLASSIFICATION: {label}\n")

summary = pd.DataFrame(results).T
summary.to_csv(f"{OUT_DIR}/phase20_cross_pair_summary.csv")
print(summary.to_string())
