"""
PHASE 25 — WALK-FORWARD VALIDATION
Strategy completely frozen (identical to Phase 21/23/24). This file only
re-buckets the SAME trades already generated in phase24.py into rolling
5yr-train / 1yr-validation / 1yr-test calendar-year windows and reports
test-window performance. No rule is touched.

Window design (calendar years, as specified):
  Window with anchor Y: TRAIN = [Y, Y+4], VALIDATION = Y+5, TEST = Y+6
  Anchors run Y = 2004 .. 2019, giving complete TEST years 2010 .. 2025
  (16 windows per pair) — matches the doc's own Window-1 example exactly.
  Data starts 2003-12-01, so 2004 is the first usable full calendar year;
  data ends 2026-09-25, so 2026 is NOT a complete calendar year. A 17th,
  explicitly-labeled PARTIAL window (train 2020-2024, val 2025,
  test = Jan-Sep 2026) is reported separately in 25G and excluded from
  every aggregate statistic.
"""

import pandas as pd
import numpy as np
from phase14 import compute_stats, max_losing_streak
from phase24 import PAIRS, build_pair

OUT_DIR = "/home/claude/backtest/phase25_results"
import os
os.makedirs(OUT_DIR, exist_ok=True)

ANCHOR_YEARS = list(range(2004, 2020))  # -> test years 2010..2025
PARTIAL_ANCHOR = 2020  # -> test = partial 2026


def bucket_trades(trades, train_start, train_end, val_year, test_year):
    entry_year = pd.to_datetime(trades["entry_date"]).dt.year
    train = trades[(entry_year >= train_start) & (entry_year <= train_end)]
    val = trades[entry_year == val_year]
    test = trades[entry_year == test_year]
    return train, val, test


all_pair_data = {}
for name, cfg in PAIRS.items():
    daily, trades = build_pair(name, cfg)
    all_pair_data[name] = trades

# ---------------- 25A-25D: build the window table ----------------
window_rows = []
for name, trades in all_pair_data.items():
    for Y in ANCHOR_YEARS:
        train_start, train_end, val_year, test_year = Y, Y + 4, Y + 5, Y + 6
        train, val, test = bucket_trades(trades, train_start, train_end, val_year, test_year)

        test_resolved = test[test["outcome"] != "open_at_data_end"].sort_values("exit_date")
        s_test = compute_stats(test)
        s_val = compute_stats(val)
        s_train = compute_stats(train)

        cum = test_resolved["r_multiple"].cumsum()
        max_dd = (cum - cum.cummax()).min() if len(cum) else 0.0
        worst_streak = max_losing_streak(test_resolved["r_multiple"].tolist())

        window_rows.append({
            "pair": name, "anchor_year": Y,
            "train_years": f"{train_start}-{train_end}", "val_year": val_year, "test_year": test_year,
            "train_trades": s_train["trade_count"], "train_R": s_train.get("total_R"),
            "val_trades": s_val["trade_count"], "val_R": s_val.get("total_R"), "val_PF": s_val.get("profit_factor"),
            "val_win_rate": s_val.get("win_rate"),
            "test_trades": s_test["trade_count"], "test_win_rate": s_test.get("win_rate"),
            "test_PF": s_test.get("profit_factor"), "test_R": s_test.get("total_R"),
            "test_avg_R": s_test.get("expectancy_R"), "test_max_DD_R": max_dd,
            "test_worst_streak": worst_streak,
        })

window_df = pd.DataFrame(window_rows)
window_df.to_csv(f"{OUT_DIR}/25_window_table.csv", index=False)

print("=== 25D: TEST WINDOW TABLE (all pairs, anchors 2004-2019 -> test years 2010-2025) ===")
print(window_df[["pair", "test_year", "test_trades", "test_win_rate", "test_PF", "test_R",
                  "test_avg_R", "test_max_DD_R", "test_worst_streak"]].to_string(index=False))

# ---------------- partial 2026 bonus window ----------------
partial_rows = []
for name, trades in all_pair_data.items():
    train_start, train_end, val_year, test_year = PARTIAL_ANCHOR, PARTIAL_ANCHOR + 4, PARTIAL_ANCHOR + 5, PARTIAL_ANCHOR + 6
    train, val, test = bucket_trades(trades, train_start, train_end, val_year, test_year)
    s_test = compute_stats(test)
    partial_rows.append({
        "pair": name, "test_period": "2026 (PARTIAL, Jan-Sep)",
        "test_trades": s_test["trade_count"], "test_win_rate": s_test.get("win_rate"),
        "test_PF": s_test.get("profit_factor"), "test_R": s_test.get("total_R"),
    })
partial_df = pd.DataFrame(partial_rows)
partial_df.to_csv(f"{OUT_DIR}/25G_partial_2026_window.csv", index=False)
print("\n=== 25G: PARTIAL 2026 TEST WINDOW (excluded from all aggregates) ===")
print(partial_df.to_string(index=False))

# ---------------- 25E: aggregated per-pair + combined ----------------
print("\n=== 25E: AGGREGATED WALK-FORWARD RESULTS (test windows only, complete years) ===")
agg_rows = []
for name in PAIRS:
    sub = window_df[window_df["pair"] == name]
    all_test_trades = all_pair_data[name].copy()
    entry_year = pd.to_datetime(all_test_trades["entry_date"]).dt.year
    pooled_test = all_test_trades[entry_year.isin(range(2010, 2026))]
    s = compute_stats(pooled_test)

    n_windows = len(sub)
    n_profitable = (sub["test_R"] > 0).sum()
    n_losing = (sub["test_R"] < 0).sum()
    n_flat = (sub["test_R"] == 0).sum()

    # longest losing-window streak
    profitable_flags = (sub.sort_values("test_year")["test_R"] > 0).tolist()
    longest_losing_streak = 0
    cur = 0
    for p in profitable_flags:
        if not p:
            cur += 1
            longest_losing_streak = max(longest_losing_streak, cur)
        else:
            cur = 0

    # aggregate drawdown across concatenated test windows in chronological order
    pooled_resolved = pooled_test[pooled_test["outcome"] != "open_at_data_end"].sort_values("exit_date")
    cum = pooled_resolved["r_multiple"].cumsum()
    max_agg_dd = (cum - cum.cummax()).min() if len(cum) else 0.0

    agg_rows.append({
        "pair": name, "total_test_trades": s["trade_count"], "aggregate_test_PF": s.get("profit_factor"),
        "aggregate_test_R": s.get("total_R"), "aggregate_test_win_rate": s.get("win_rate"),
        "avg_R_per_trade": s.get("expectancy_R"), "n_windows": n_windows,
        "pct_profitable_windows": n_profitable / n_windows if n_windows else np.nan,
        "pct_losing_windows": n_losing / n_windows if n_windows else np.nan,
        "n_flat_windows": n_flat,
        "longest_losing_window_streak": longest_losing_streak,
        "max_aggregate_DD_R": max_agg_dd,
    })
agg_df = pd.DataFrame(agg_rows)
agg_df.to_csv(f"{OUT_DIR}/25E_aggregated_per_pair.csv", index=False)
print(agg_df.to_string(index=False))

# combined portfolio-style (pool all four pairs' test trades together)
combined_test = pd.concat([
    all_pair_data[name][pd.to_datetime(all_pair_data[name]["entry_date"]).dt.year.isin(range(2010, 2026))]
    for name in PAIRS
], ignore_index=True)
s_combined = compute_stats(combined_test)
combined_resolved = combined_test[combined_test["outcome"] != "open_at_data_end"].sort_values("exit_date")
cum_c = combined_resolved["r_multiple"].cumsum()
max_dd_c = (cum_c - cum_c.cummax()).min() if len(cum_c) else 0.0
print(f"\nCOMBINED (all 4 pairs pooled, test windows only): trades={s_combined['trade_count']} "
      f"PF={s_combined.get('profit_factor'):.3f} totalR={s_combined.get('total_R'):.2f} "
      f"win_rate={s_combined.get('win_rate'):.1%} maxAggDD={max_dd_c:.2f}")

pd.DataFrame([{
    "trades": s_combined["trade_count"], "PF": s_combined.get("profit_factor"),
    "total_R": s_combined.get("total_R"), "win_rate": s_combined.get("win_rate"),
    "max_agg_DD_R": max_dd_c,
}]).to_csv(f"{OUT_DIR}/25E_combined_portfolio.csv", index=False)

# ---------------- 25F: consistency ----------------
print("\n=== 25F: CONSISTENCY ===")
for name in PAIRS:
    sub = window_df[window_df["pair"] == name].sort_values("test_year")
    prof = sub[sub["test_R"] > 0]
    los = sub[sub["test_R"] < 0]
    top3_share = prof.sort_values("test_R", ascending=False).head(3)["test_R"].sum() / prof["test_R"].sum() if len(prof) and prof["test_R"].sum() > 0 else np.nan
    # trend: split into first half vs second half of test years
    half = len(sub) // 2
    first_half_R = sub.iloc[:half]["test_R"].sum()
    second_half_R = sub.iloc[half:]["test_R"].sum()
    print(f"\n{name}: {len(prof)}/{len(sub)} profitable windows, {len(los)}/{len(sub)} losing "
          f"({(len(sub)-len(prof)-len(los))} flat)")
    print(f"  top-3 profitable windows = {top3_share:.1%} of total positive test R (n_profitable={len(prof)})")
    print(f"  first-half test-year total R = {first_half_R:.2f}, second-half = {second_half_R:.2f}")
    losing_years = sub[sub['test_R'] < 0]['test_year'].tolist()
    print(f"  losing test years: {losing_years}")

# ---------------- 25H: cross-pair persistence of Phase-24 regime traits ----------------
print("\n=== 25H: CROSS-PAIR CONSISTENCY (does the GBP/USD strong-trend weakness persist?) ===")
for name in PAIRS:
    trades = all_pair_data[name]
    test_trades = trades[pd.to_datetime(trades["entry_date"]).dt.year.isin(range(2010, 2026))]
    test_resolved = test_trades[test_trades["outcome"] != "open_at_data_end"]
    strong = test_resolved[test_resolved["trend_regime"] == "STRONG"]
    s_strong = compute_stats(strong)
    print(f"{name}: STRONG-trend trades within walk-forward test windows: n={s_strong['trade_count']} "
          f"PF={s_strong.get('profit_factor', float('nan')):.2f} totalR={s_strong.get('total_R', float('nan')):.2f}")

print("\nAll Phase 25 CSVs saved to", OUT_DIR)
