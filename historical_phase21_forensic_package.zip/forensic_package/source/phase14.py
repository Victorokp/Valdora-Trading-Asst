"""
PHASE 14 — Test fundamentally different strategy families on EUR/USD.
Rules for every candidate are FROZEN BEFORE looking at the final holdout.
Same execution engine, same cost model, same split methodology as the
earlier weekly-trend/daily-pullback work, so results are comparable.

Execution engine (identical for every strategy tested here):
  - Signal computed using only information available at/by the signal day
    (no lookahead).
  - Entry at NEXT day's open, plus 1.5-pip friction (long-only, so this is
    the cost of buying).
  - Stop/target are ATR-multiples fixed at signal time.
  - Gap-aware exits: if next day's OPEN already gaps through the stop or
    target, fill at the OPEN. Otherwise fill at the stop/target price if
    the day's low/high crosses it.
  - If both stop and target are touched intrabar on a non-gap day, the
    stop is assumed to hit first (conservative).
  - Unresolved trades at end of data are closed at last close and flagged
    'open_at_data_end', excluded from win-rate/PF stats.
  - Chronological 70/15/15 train/validation/final split by ENTRY date.

Candidates (each hypothesis frozen below, none tuned on the holdout):

  A. MEAN REVERSION
     Filter : Close > EMA200 (only buy dips within an established
              longer-term uptrend — avoids catching falling knives)
     Signal : RSI(14) < 30 (oversold)
     Stop   : entry - 1.0*ATR14   Target: entry + 1.0*ATR14
     (symmetric R:R — reversion trades are expected to have a higher win
     rate rather than a large payoff)

  B. MOMENTUM CONTINUATION
     Signal : Close makes a new 20-day high AND 10-day rate-of-change > 0
              (confirms the breakout is backed by recent momentum, not a
              1-day spike)
     Stop   : entry - 1.5*ATR14   Target: entry + 3.0*ATR14
     (trend-following payoff structure — lower expected win rate, larger
     expected winners)

  C. VOLATILITY BREAKOUT
     Filter : ATR14 has contracted — ATR14 < 0.75 * (20-day average of
              ATR14) on the signal day (a "squeeze")
     Signal : Close breaks above the prior 10-day high
     Stop   : entry - 1.0*ATR14   Target: entry + 2.0*ATR14
     (same R:R as the earlier trend-pullback baseline, different trigger)

  D. TREND PULLBACK — not re-run here; already evaluated in the prior
     multi-pair phase. Kept only as the existing reference candidate.
"""

import pandas as pd
import numpy as np
import os

FILE = "/mnt/user-data/uploads/eurusd_d.csv"
PIP = 0.0001
FRICTION_PIPS = 1.5
SPLIT_TRAIN = 0.70
SPLIT_VAL = 0.15
START_DATE = "2003-12-01"  # matches earlier EUR/USD + multi-pair work

OUT_DIR = "/home/claude/backtest/phase14_results"
os.makedirs(OUT_DIR, exist_ok=True)


def load_daily(path, start_date=None):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    df["Date"] = pd.to_datetime(df["Date"])
    df = df.sort_values("Date").reset_index(drop=True)
    for c in ["Open", "High", "Low", "Close"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["Open", "High", "Low", "Close"]).reset_index(drop=True)
    if start_date:
        df = df[df["Date"] >= pd.Timestamp(start_date)].reset_index(drop=True)
    return df


def ema(series, span):
    return series.ewm(span=span, adjust=False).mean()


def rsi(series, period=14):
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    out = 100 - (100 / (1 + rs))
    out = out.fillna(100)  # avg_loss==0 -> maximally overbought
    return out


def atr(df, period=14):
    prev_close = df["Close"].shift(1)
    tr = pd.concat([
        df["High"] - df["Low"],
        (df["High"] - prev_close).abs(),
        (df["Low"] - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False).mean()


def simulate_trades(daily, signal_col, stop_mult, target_mult, friction_pips=FRICTION_PIPS, pip=PIP):
    friction = friction_pips * pip
    n = len(daily)
    signal_idxs = daily.index[daily[signal_col]].tolist()
    trades = []

    for i in signal_idxs:
        entry_i = i + 1
        if entry_i >= n:
            continue
        sig_atr = daily.loc[i, "ATR"]
        if pd.isna(sig_atr) or sig_atr <= 0:
            continue
        entry_date = daily.loc[entry_i, "Date"]
        entry_price = daily.loc[entry_i, "Open"] + friction
        stop_price = entry_price - stop_mult * sig_atr
        target_price = entry_price + target_mult * sig_atr
        risk = entry_price - stop_price
        if risk <= 0:
            continue

        exit_price = None
        exit_date = None
        outcome = None

        for j in range(entry_i, n):
            o = daily.loc[j, "Open"]
            lo = daily.loc[j, "Low"]
            hi = daily.loc[j, "High"]

            gap_stop = o <= stop_price
            gap_target = o >= target_price

            if gap_stop:
                exit_price, outcome = o, "gap_stop"
                exit_date = daily.loc[j, "Date"]
                break
            elif gap_target:
                exit_price, outcome = o, "gap_target"
                exit_date = daily.loc[j, "Date"]
                break

            hit_stop = lo <= stop_price
            hit_target = hi >= target_price
            if hit_stop and hit_target:
                exit_price, outcome = stop_price, "stop_assumed_first"
                exit_date = daily.loc[j, "Date"]
                break
            elif hit_stop:
                exit_price, outcome = stop_price, "stop"
                exit_date = daily.loc[j, "Date"]
                break
            elif hit_target:
                exit_price, outcome = target_price, "target"
                exit_date = daily.loc[j, "Date"]
                break

        if exit_price is None:
            exit_price = daily.loc[n - 1, "Close"]
            outcome = "open_at_data_end"
            exit_date = daily.loc[n - 1, "Date"]

        r_multiple = (exit_price - entry_price) / risk
        trades.append({
            "signal_date": daily.loc[i, "Date"],
            "entry_date": entry_date,
            "exit_date": exit_date,
            "entry_price": entry_price,
            "stop_price": stop_price,
            "target_price": target_price,
            "exit_price": exit_price,
            "atr_at_signal": sig_atr,
            "outcome": outcome,
            "r_multiple": r_multiple,
        })

    return pd.DataFrame(trades)


def split_trades(trades_df, daily):
    if len(trades_df) == 0:
        return trades_df
    dates = daily["Date"]
    start, end = dates.iloc[0], dates.iloc[-1]
    total_days = (end - start).days
    train_end = start + pd.Timedelta(days=int(total_days * SPLIT_TRAIN))
    val_end = start + pd.Timedelta(days=int(total_days * (SPLIT_TRAIN + SPLIT_VAL)))

    def bucket(d):
        if d <= train_end:
            return "train"
        elif d <= val_end:
            return "validation"
        else:
            return "final"

    trades_df = trades_df.copy()
    trades_df["split"] = trades_df["entry_date"].apply(bucket)
    return trades_df


def max_losing_streak(r_series):
    streak = 0
    worst = 0
    for r in r_series:
        if r <= 0:
            streak += 1
            worst = max(worst, streak)
        else:
            streak = 0
    return worst


def compute_stats(sub):
    resolved = sub[sub["outcome"] != "open_at_data_end"]
    n_trades = len(sub)
    n_resolved = len(resolved)
    if n_resolved == 0:
        return {
            "trade_count": n_trades, "resolved_count": 0, "win_rate": np.nan,
            "profit_factor": np.nan, "total_R": sub["r_multiple"].sum() if n_trades else 0.0,
            "expectancy_R": np.nan, "max_drawdown_R": np.nan, "worst_losing_streak": np.nan,
        }
    ordered = resolved.sort_values("exit_date")
    wins = ordered[ordered["r_multiple"] > 0]
    losses = ordered[ordered["r_multiple"] <= 0]
    win_rate = len(wins) / n_resolved
    gross_win = wins["r_multiple"].sum()
    gross_loss = -losses["r_multiple"].sum()
    profit_factor = (gross_win / gross_loss) if gross_loss > 0 else np.inf
    total_R = ordered["r_multiple"].sum()
    cum = ordered["r_multiple"].cumsum()
    running_max = cum.cummax()
    dd = cum - running_max
    max_dd = dd.min() if len(dd) else 0.0
    streak = max_losing_streak(ordered["r_multiple"].tolist())

    return {
        "trade_count": n_trades, "resolved_count": n_resolved, "win_rate": win_rate,
        "profit_factor": profit_factor, "total_R": total_R,
        "expectancy_R": total_R / n_resolved, "max_drawdown_R": max_dd,
        "worst_losing_streak": streak,
    }


def evaluate_strategy(name, daily, signal_col, stop_mult, target_mult, warmup):
    d = daily.copy()
    d.loc[: warmup - 1, signal_col] = False
    trades_df = simulate_trades(d, signal_col, stop_mult, target_mult)
    if len(trades_df) == 0:
        print(f"  {name}: NO TRADES generated. Rejected — recording failure, moving on.")
        return None, [{"strategy": name, "split": "ALL", "trade_count": 0, "note": "no trades generated"}]

    trades_df = split_trades(trades_df, d)
    trades_df.to_csv(f"{OUT_DIR}/{name}_trades.csv", index=False)

    rows = []
    for split_name in ["train", "validation", "final"]:
        sub = trades_df[trades_df["split"] == split_name]
        stats = compute_stats(sub)
        stats["strategy"] = name
        stats["split"] = split_name
        rows.append(stats)
        wr = stats.get("win_rate", float("nan"))
        pf = stats.get("profit_factor", float("nan"))
        print(f"  {name:20s} {split_name:10s} trades={stats['trade_count']:>4} "
              f"win_rate={wr:.1%} PF={pf:.2f} totalR={stats.get('total_R', float('nan')):.2f} "
              f"exp={stats.get('expectancy_R', float('nan')):.3f} maxDD={stats.get('max_drawdown_R', float('nan')):.2f} "
              f"worstStreak={stats.get('worst_losing_streak', float('nan'))}")

    overall = compute_stats(trades_df)
    overall["strategy"] = name
    overall["split"] = "ALL"
    rows.append(overall)
    print(f"  {name:20s} {'ALL':10s} trades={overall['trade_count']:>4} "
          f"win_rate={overall.get('win_rate', float('nan')):.1%} PF={overall.get('profit_factor', float('nan')):.2f} "
          f"totalR={overall.get('total_R', float('nan')):.2f} exp={overall.get('expectancy_R', float('nan')):.3f} "
          f"maxDD={overall.get('max_drawdown_R', float('nan')):.2f} worstStreak={overall.get('worst_losing_streak', float('nan'))}")
    return trades_df, rows


# ---------------------------------------------------------------- data prep
daily = load_daily(FILE, START_DATE)
daily["EMA200"] = ema(daily["Close"], 200)
daily["RSI14"] = rsi(daily["Close"], 14)
daily["ATR"] = atr(daily, 14)
daily["ROC10"] = daily["Close"].pct_change(10)
daily["High20"] = daily["High"].rolling(20).max().shift(1)  # prior 20-day high (no lookahead)
daily["High10"] = daily["High"].rolling(10).max().shift(1)  # prior 10-day high
daily["ATR_avg20"] = daily["ATR"].rolling(20).mean()

all_rows = []
all_trades = {}

print("=== PHASE 14: candidate strategy families on EUR/USD ===\n")

# ---- A. Mean reversion ----
daily["sig_meanrev"] = (daily["Close"] > daily["EMA200"]) & (daily["RSI14"] < 30)
try:
    td, rows = evaluate_strategy("A_mean_reversion", daily, "sig_meanrev",
                                  stop_mult=1.0, target_mult=1.0, warmup=205)
    all_rows.extend(rows)
    if td is not None:
        all_trades["A_mean_reversion"] = td
except Exception as e:
    print(f"  A_mean_reversion: ERROR {e}. Recording failure, continuing.")
    all_rows.append({"strategy": "A_mean_reversion", "split": "ERROR", "note": str(e)})

# ---- B. Momentum continuation ----
daily["sig_momentum"] = (daily["High"] >= daily["High20"]) & (daily["Close"] >= daily["High20"]) & (daily["ROC10"] > 0)
try:
    td, rows = evaluate_strategy("B_momentum_continuation", daily, "sig_momentum",
                                  stop_mult=1.5, target_mult=3.0, warmup=25)
    all_rows.extend(rows)
    if td is not None:
        all_trades["B_momentum_continuation"] = td
except Exception as e:
    print(f"  B_momentum_continuation: ERROR {e}. Recording failure, continuing.")
    all_rows.append({"strategy": "B_momentum_continuation", "split": "ERROR", "note": str(e)})

# ---- C. Volatility breakout ----
daily["sig_volbreak"] = (daily["ATR"] < 0.75 * daily["ATR_avg20"]) & (daily["Close"] > daily["High10"])
try:
    td, rows = evaluate_strategy("C_volatility_breakout", daily, "sig_volbreak",
                                  stop_mult=1.0, target_mult=2.0, warmup=25)
    all_rows.extend(rows)
    if td is not None:
        all_trades["C_volatility_breakout"] = td
except Exception as e:
    print(f"  C_volatility_breakout: ERROR {e}. Recording failure, continuing.")
    all_rows.append({"strategy": "C_volatility_breakout", "split": "ERROR", "note": str(e)})

summary_df = pd.DataFrame(all_rows)
summary_df.to_csv(f"{OUT_DIR}/phase14_summary.csv", index=False)
print("\nSaved to", OUT_DIR)
print(summary_df.to_string(index=False))
