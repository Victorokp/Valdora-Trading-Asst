"""
PHASE 24 — REGIME / TIME STABILITY DIAGNOSTICS
Strategy is NOT modified anywhere in this file. Every computation below
reuses the exact frozen Phase-21 signal/trade set per pair; this file
only classifies and slices those existing trades for diagnostic purposes.
"""

import pandas as pd
import numpy as np
from phase14 import load_daily, ema, atr as atr_func, simulate_trades, split_trades, compute_stats, max_losing_streak
from phase21 import build_weekly_filter, map_weekly_to_daily
from phase20 import adx14

PAIRS = {
    "EURUSD": {"file": "/mnt/user-data/uploads/eurusd_d.csv", "pip": 0.0001},
    "GBPUSD": {"file": "/mnt/user-data/uploads/gbpusd_d.csv", "pip": 0.0001},
    "USDJPY": {"file": "/mnt/user-data/uploads/usdjpy_d.csv", "pip": 0.01},
    "AUDUSD": {"file": "/mnt/user-data/uploads/audusd_d.csv", "pip": 0.0001},
}
START_DATE = "2003-12-01"
OUT_DIR = "/home/claude/backtest/phase24_results"
import os
os.makedirs(OUT_DIR, exist_ok=True)


def build_pair(name, cfg):
    daily = load_daily(cfg["file"], START_DATE)
    daily["EMA20"] = ema(daily["Close"], 20)
    daily["EMA50"] = ema(daily["Close"], 50)
    daily["EMA50_rising"] = daily["EMA50"] > daily["EMA50"].shift(5)
    daily["ATR"] = atr_func(daily, 14)
    daily["PrevHigh"] = daily["High"].shift(1)
    daily["ADX14"] = adx14(daily, 14)
    daily["ATR_q33"] = daily["ATR"].rolling(100).quantile(0.33)
    daily["ATR_q67"] = daily["ATR"].rolling(100).quantile(0.67)

    weekly_ok = build_weekly_filter(daily)
    daily["weekly_ok"] = map_weekly_to_daily(daily, weekly_ok)
    daily["daily_trend_ok"] = (daily["EMA20"] > daily["EMA50"]) & daily["EMA50_rising"]
    daily["pullback"] = (daily["Low"] <= daily["EMA20"]) & (daily["Close"] > daily["EMA20"])
    daily["confirm"] = daily["Close"] > daily["PrevHigh"]
    daily["signal"] = daily["weekly_ok"] & daily["daily_trend_ok"] & daily["pullback"] & daily["confirm"]
    daily.loc[:59, "signal"] = False

    trades = simulate_trades(daily, "signal", stop_mult=1.0, target_mult=2.0, friction_pips=1.5, pip=cfg["pip"])
    trades = split_trades(trades, daily)

    # attach regime info at signal time
    lookup = daily.set_index("Date")[["ATR", "ADX14", "ATR_q33", "ATR_q67"]]
    trades = trades.merge(lookup, left_on="signal_date", right_index=True, how="left")

    def vol_regime(row):
        if pd.isna(row["ATR_q33"]) or pd.isna(row["ATR_q67"]):
            return "unknown"
        if row["ATR"] <= row["ATR_q33"]:
            return "LOW"
        elif row["ATR"] >= row["ATR_q67"]:
            return "HIGH"
        return "MEDIUM"

    def trend_regime(row):
        if pd.isna(row["ADX14"]):
            return "unknown"
        if row["ADX14"] < 20:
            return "WEAK"
        elif row["ADX14"] < 25:
            return "MODERATE"
        return "STRONG"

    trades["vol_regime"] = trades.apply(vol_regime, axis=1)
    trades["trend_regime"] = trades.apply(trend_regime, axis=1)
    trades["holding_days"] = (pd.to_datetime(trades["exit_date"]) - pd.to_datetime(trades["entry_date"])).dt.days
    trades["exit_year"] = pd.to_datetime(trades["exit_date"]).dt.year
    trades["is_win"] = trades["r_multiple"] > 0

    return daily, trades


def stats_for(df):
    return compute_stats(df)


all_pair_data = {}
for name, cfg in PAIRS.items():
    daily, trades = build_pair(name, cfg)
    all_pair_data[name] = (daily, trades)
    trades.to_csv(f"{OUT_DIR}/{name}_trades_with_regimes.csv", index=False)

print("Built regime-tagged trade sets for all 4 pairs.\n")

# ---------------- 24A: year-by-year ----------------
print("=== 24A: YEAR-BY-YEAR ===")
yearly_all = []
for name, (daily, trades) in all_pair_data.items():
    resolved = trades[trades["outcome"] != "open_at_data_end"]
    for yr, g in resolved.groupby("exit_year"):
        s = stats_for(g)
        yearly_all.append({
            "pair": name, "year": yr, "trades": len(g), "win_rate": s.get("win_rate"),
            "PF": s.get("profit_factor"), "total_R": s.get("total_R"),
            "avg_R": s.get("expectancy_R"), "worst_streak": max_losing_streak(g.sort_values("exit_date")["r_multiple"].tolist()),
        })
yearly_df = pd.DataFrame(yearly_all)
yearly_df.to_csv(f"{OUT_DIR}/24A_yearly.csv", index=False)
for name in PAIRS:
    sub = yearly_df[yearly_df["pair"] == name]
    print(f"\n{name}:")
    print(sub[["year", "trades", "win_rate", "PF", "total_R", "avg_R", "worst_streak"]].to_string(index=False))

# ---------------- 24B: rolling performance ----------------
print("\n=== 24B: ROLLING PERFORMANCE ===")
rolling_all = []
for name, (daily, trades) in all_pair_data.items():
    resolved = trades[trades["outcome"] != "open_at_data_end"].sort_values("exit_date").reset_index(drop=True)
    resolved["exit_date_dt"] = pd.to_datetime(resolved["exit_date"])
    # 3-year rolling total R / PF using a date-based rolling window
    r = resolved.set_index("exit_date_dt")["r_multiple"]
    roll_3y_sum = r.rolling("1095D").sum()
    def pf_roll(x):
        pos = x[x > 0].sum()
        neg = -x[x <= 0].sum()
        return pos / neg if neg > 0 else np.nan
    roll_3y_pf = r.rolling("1095D").apply(pf_roll, raw=False)
    roll_20trade_avgR = resolved["r_multiple"].rolling(20, min_periods=20).mean()
    roll_30trade_pf = resolved["r_multiple"].rolling(30, min_periods=30).apply(
        lambda x: (x[x > 0].sum() / -x[x <= 0].sum()) if (-x[x <= 0].sum()) > 0 else np.nan, raw=False)

    out = pd.DataFrame({
        "pair": name,
        "exit_date": resolved["exit_date"],
        "roll_3y_total_R": roll_3y_sum.values,
        "roll_3y_PF": roll_3y_pf.values,
        "roll_20trade_avg_R": roll_20trade_avgR.values,
        "roll_30trade_PF": roll_30trade_pf.values,
    })
    rolling_all.append(out)
    # identify deterioration: min of roll_20trade_avgR and where
    min_idx = roll_20trade_avgR.idxmin() if roll_20trade_avgR.notna().any() else None
    if min_idx is not None:
        worst_date = resolved.loc[min_idx, "exit_date"]
        worst_val = roll_20trade_avgR.loc[min_idx]
        print(f"{name}: weakest 20-trade rolling avg R = {worst_val:.3f} around exit date {worst_date}")

rolling_df = pd.concat(rolling_all, ignore_index=True)
rolling_df.to_csv(f"{OUT_DIR}/24B_rolling.csv", index=False)

# ---------------- 24C: volatility regimes ----------------
print("\n=== 24C: VOLATILITY REGIMES ===")
vol_rows = []
for name, (daily, trades) in all_pair_data.items():
    resolved = trades[trades["outcome"] != "open_at_data_end"]
    for regime, g in resolved.groupby("vol_regime"):
        s = stats_for(g)
        vol_rows.append({"pair": name, "vol_regime": regime, "trades": len(g),
                          "win_rate": s.get("win_rate"), "PF": s.get("profit_factor"),
                          "total_R": s.get("total_R"), "avg_R": s.get("expectancy_R")})
vol_df = pd.DataFrame(vol_rows)
vol_df.to_csv(f"{OUT_DIR}/24C_volatility_regimes.csv", index=False)
print(vol_df.to_string(index=False))

# ---------------- 24D: trend-strength regimes ----------------
print("\n=== 24D: TREND-STRENGTH REGIMES ===")
trend_rows = []
for name, (daily, trades) in all_pair_data.items():
    resolved = trades[trades["outcome"] != "open_at_data_end"]
    for regime, g in resolved.groupby("trend_regime"):
        s = stats_for(g)
        trend_rows.append({"pair": name, "trend_regime": regime, "trades": len(g),
                            "win_rate": s.get("win_rate"), "PF": s.get("profit_factor"),
                            "total_R": s.get("total_R"), "avg_R": s.get("expectancy_R")})
trend_df = pd.DataFrame(trend_rows)
trend_df.to_csv(f"{OUT_DIR}/24D_trend_regimes.csv", index=False)
print(trend_df.to_string(index=False))

# ---------------- 24E: validation-period forensics (EURUSD, GBPUSD) ----------------
print("\n=== 24E: VALIDATION-PERIOD FORENSICS ===")
for name in ["EURUSD", "GBPUSD"]:
    daily, trades = all_pair_data[name]
    val = trades[trades["split"] == "validation"].copy()
    val_out = val[["entry_date", "entry_price", "stop_price", "target_price", "r_multiple",
                    "holding_days", "vol_regime", "trend_regime", "is_win", "outcome"]]
    val_out.to_csv(f"{OUT_DIR}/24E_validation_forensics_{name}.csv", index=False)
    print(f"\n{name} validation trades ({len(val)}):")
    print(val_out.to_string(index=False))

# ---------------- 24F: losing-streak analysis ----------------
print("\n=== 24F: LOSING-STREAK ANALYSIS ===")
streak_rows = []
for name, (daily, trades) in all_pair_data.items():
    resolved = trades[trades["outcome"] != "open_at_data_end"].sort_values("exit_date")
    r_list = resolved["r_multiple"].tolist()
    streaks = []
    cur = 0
    cur_R = 0.0
    streak_Rs = []
    for r in r_list:
        if r <= 0:
            cur += 1
            cur_R += r
        else:
            if cur > 0:
                streaks.append(cur)
                streak_Rs.append(cur_R)
            cur = 0
            cur_R = 0.0
    if cur > 0:
        streaks.append(cur)
        streak_Rs.append(cur_R)

    # recovery time: time from equity trough to new equity high, in trades
    cum = resolved["r_multiple"].cumsum().values
    running_max = np.maximum.accumulate(cum)
    in_dd = cum < running_max
    # find max drawdown recovery length in number of trades
    recovery_lengths = []
    i = 0
    n = len(cum)
    while i < n:
        if in_dd[i]:
            start = i
            while i < n and in_dd[i]:
                i += 1
            recovery_lengths.append(i - start)
        else:
            i += 1

    # split final-holdout streak comparison
    final_resolved = trades[(trades["split"] == "final") & (trades["outcome"] != "open_at_data_end")].sort_values("exit_date")
    final_worst_streak = max_losing_streak(final_resolved["r_multiple"].tolist())

    streak_rows.append({
        "pair": name,
        "max_losing_streak": max(streaks) if streaks else 0,
        "avg_losing_streak": np.mean(streaks) if streaks else 0,
        "n_losing_streaks": len(streaks),
        "max_consecutive_losing_R": min(streak_Rs) if streak_Rs else 0,
        "max_recovery_trades": max(recovery_lengths) if recovery_lengths else 0,
        "avg_recovery_trades": np.mean(recovery_lengths) if recovery_lengths else 0,
        "final_holdout_worst_streak": final_worst_streak,
    })
streak_df = pd.DataFrame(streak_rows)
streak_df.to_csv(f"{OUT_DIR}/24F_losing_streaks.csv", index=False)
print(streak_df.to_string(index=False))

# ---------------- 24G: trade concentration ----------------
print("\n=== 24G: TRADE CONCENTRATION ===")
conc_rows = []
for name, (daily, trades) in all_pair_data.items():
    resolved = trades[trades["outcome"] != "open_at_data_end"]
    wins = resolved[resolved["r_multiple"] > 0].sort_values("r_multiple", ascending=False)
    losses = resolved[resolved["r_multiple"] <= 0].sort_values("r_multiple")
    gross_profit = wins["r_multiple"].sum()
    gross_loss = -losses["r_multiple"].sum()
    row = {"pair": name, "n_wins": len(wins), "n_losses": len(losses),
           "gross_profit_R": gross_profit, "gross_loss_R": gross_loss}
    for k in [1, 5, 10, 20]:
        row[f"top{k}_winner_share"] = wins.head(k)["r_multiple"].sum() / gross_profit if gross_profit > 0 else np.nan
        row[f"top{k}_loser_share"] = -losses.head(k)["r_multiple"].sum() / gross_loss if gross_loss > 0 else np.nan
    conc_rows.append(row)
conc_df = pd.DataFrame(conc_rows)
conc_df.to_csv(f"{OUT_DIR}/24G_concentration.csv", index=False)
print(conc_df.to_string(index=False))

# ---------------- 24H: market-regime matrix ----------------
print("\n=== 24H: MARKET-REGIME MATRIX ===")
matrix_rows = []
for name, (daily, trades) in all_pair_data.items():
    resolved = trades[trades["outcome"] != "open_at_data_end"]
    for dim, col in [("vol", "vol_regime"), ("trend", "trend_regime")]:
        for regime, g in resolved.groupby(col):
            s = stats_for(g)
            matrix_rows.append({"pair": name, "dimension": dim, "regime": regime,
                                 "trades": len(g), "PF": s.get("profit_factor"), "avg_R": s.get("expectancy_R")})
matrix_df = pd.DataFrame(matrix_rows)
matrix_df.to_csv(f"{OUT_DIR}/24H_regime_matrix.csv", index=False)
print(matrix_df.to_string(index=False))

# ---------------- 24I: train/val/final comparison ----------------
print("\n=== 24I: TRAIN / VALIDATION / FINAL COMPARISON ===")
split_comp_rows = []
for name, (daily, trades) in all_pair_data.items():
    for split_name in ["train", "validation", "final"]:
        sub = trades[trades["split"] == split_name]
        resolved = sub[sub["outcome"] != "open_at_data_end"]
        s = stats_for(sub)
        vol_dist = resolved["vol_regime"].value_counts(normalize=True).to_dict()
        trend_dist = resolved["trend_regime"].value_counts(normalize=True).to_dict()
        split_comp_rows.append({
            "pair": name, "split": split_name, "trades": s["trade_count"],
            "win_rate": s.get("win_rate"), "PF": s.get("profit_factor"), "avg_R": s.get("expectancy_R"),
            "vol_LOW_pct": vol_dist.get("LOW", 0), "vol_MEDIUM_pct": vol_dist.get("MEDIUM", 0), "vol_HIGH_pct": vol_dist.get("HIGH", 0),
            "trend_WEAK_pct": trend_dist.get("WEAK", 0), "trend_MODERATE_pct": trend_dist.get("MODERATE", 0), "trend_STRONG_pct": trend_dist.get("STRONG", 0),
        })
split_comp_df = pd.DataFrame(split_comp_rows)
split_comp_df.to_csv(f"{OUT_DIR}/24I_split_comparison.csv", index=False)
print(split_comp_df.to_string(index=False))

print("\nAll Phase 24 CSVs saved to", OUT_DIR)
