"""
PHASE 15 RECONCILIATION — VERDICT
None of the 24 pre-registered grid combinations (2 ATR constructions x 3
lookbacks x 2 percentile conventions x 2 breakout definitions) reproduced
anything close to the claimed 110 trades / PF 1.37 / +30.40R. Best case by
trade count (wilder ATR, 200-bar lookback, close-vs-close20 breakout) gave
99 trades but PF 1.00 and ~0R total — still not the claimed result, and
every other combination in the grid is worse. No combination exceeded
PF 1.15 or +7R.

VERDICT: "Phase-15 historical claim could not be reproduced under the
pre-registered diagnostic definitions." Candidate discarded, not carried
forward. Per the automatic-fallback instruction, moving directly to
Phase 21.

===========================================================================
PHASE 21 — REGIME-FILTERED TREND PULLBACK (fresh reproduction, EUR/USD)
===========================================================================
This is NOT a reuse of the earlier trend-pullback multi-pair results —
rebuilt from scratch under the current engine, per instructions.

Frozen rules:
  Weekly filter : EMA10 > EMA20  AND  weekly close > weekly EMA20
  Daily trend   : EMA20 > EMA50  AND  EMA50 rising (EMA50 > EMA50 five
                  days ago — same "rising" convention used earlier in
                  this research for EMA200)
  Pullback      : Low <= EMA20  AND  Close > EMA20 (dips into the EMA20
                  but closes back above it)
  Confirmation  : Close > previous day's high
  Entry         : next day's open
  Stop          : 1.0 * ATR14      Target: 2.0 * ATR14
  Friction      : 1.5 pips
  Direction     : long only
  Split         : chronological 70/15/15 by entry date

Pre-registered rejection criteria (fixed before viewing results):
  Reject if: overall PF < 1.0, OR final-holdout PF < 1.0, OR final-holdout
  total R < 0, OR total trades < 20, OR the top 10 winning trades account
  for > 60% of total positive R (concentration check).
"""

import pandas as pd
import numpy as np
from phase14 import load_daily, ema, atr as atr_func, simulate_trades, split_trades, compute_stats, max_losing_streak

FILE = "/mnt/user-data/uploads/eurusd_d.csv"
PIP = 0.0001
START_DATE = "2003-12-01"
OUT_DIR = "/home/claude/backtest/phase21_results"
import os
os.makedirs(OUT_DIR, exist_ok=True)


def build_weekly_filter(daily):
    w = daily.set_index("Date").resample("W-FRI").agg(
        {"Open": "first", "High": "max", "Low": "min", "Close": "last"}
    ).dropna()
    w["EMA10"] = ema(w["Close"], 10)
    w["EMA20"] = ema(w["Close"], 20)
    w["weekly_ok"] = (w["EMA10"] > w["EMA20"]) & (w["Close"] > w["EMA20"])
    return w["weekly_ok"]


def map_weekly_to_daily(daily, weekly_ok):
    fridays = weekly_ok.index.values
    vals = weekly_ok.values
    daily_dates = daily["Date"].values
    idx = np.searchsorted(fridays, daily_dates, side="left") - 1
    result = np.full(len(daily), False)
    valid = idx >= 0
    result[valid] = vals[idx[valid]]
    return pd.Series(result, index=daily.index)


daily = load_daily(FILE, START_DATE)
daily["EMA20"] = ema(daily["Close"], 20)
daily["EMA50"] = ema(daily["Close"], 50)
daily["EMA50_rising"] = daily["EMA50"] > daily["EMA50"].shift(5)
daily["ATR"] = atr_func(daily, 14)
daily["PrevHigh"] = daily["High"].shift(1)

weekly_ok = build_weekly_filter(daily)
daily["weekly_ok"] = map_weekly_to_daily(daily, weekly_ok)

daily["daily_trend_ok"] = (daily["EMA20"] > daily["EMA50"]) & daily["EMA50_rising"]
daily["pullback"] = (daily["Low"] <= daily["EMA20"]) & (daily["Close"] > daily["EMA20"])
daily["confirm"] = daily["Close"] > daily["PrevHigh"]

daily["signal"] = daily["weekly_ok"] & daily["daily_trend_ok"] & daily["pullback"] & daily["confirm"]
warmup = 60
daily.loc[: warmup - 1, "signal"] = False

print("=== PHASE 21: regime-filtered trend pullback, EUR/USD ===\n")
print(f"Raw signal count: {daily['signal'].sum()}\n")

trades_df = simulate_trades(daily, "signal", stop_mult=1.0, target_mult=2.0, friction_pips=1.5, pip=PIP)
trades_df = split_trades(trades_df, daily)
trades_df.to_csv(f"{OUT_DIR}/phase21_trades.csv", index=False)

overall = compute_stats(trades_df)
split_stats = {}
for s in ["train", "validation", "final"]:
    sub = trades_df[trades_df["split"] == s]
    split_stats[s] = compute_stats(sub)

print(f"OVERALL: trades={overall['trade_count']} win_rate={overall.get('win_rate', float('nan')):.1%} "
      f"PF={overall.get('profit_factor', float('nan')):.2f} totalR={overall.get('total_R', float('nan')):.2f} "
      f"avgR={overall.get('expectancy_R', float('nan')):.3f} maxDD={overall.get('max_drawdown_R', float('nan')):.2f} "
      f"worstStreak={overall.get('worst_losing_streak', float('nan'))}")
for s in ["train", "validation", "final"]:
    st = split_stats[s]
    print(f"  {s:10s} trades={st['trade_count']:>4} win_rate={st.get('win_rate', float('nan')):.1%} "
          f"PF={st.get('profit_factor', float('nan')):.2f} totalR={st.get('total_R', float('nan')):.2f}")

# ---- year-by-year ----
resolved = trades_df[trades_df["outcome"] != "open_at_data_end"].copy()
resolved["exit_year"] = pd.to_datetime(resolved["exit_date"]).dt.year
yearly = resolved.groupby("exit_year")["r_multiple"].agg(["count", "sum"]).rename(columns={"count": "trades", "sum": "total_R"})
yearly.to_csv(f"{OUT_DIR}/phase21_yearly.csv")
print("\nYear-by-year (exit year):")
print(yearly.to_string())

# ---- cost sensitivity ----
print("\nCost sensitivity:")
cost_rows = []
for friction_pips in [0, 1.5, 3, 5, 10]:
    td = simulate_trades(daily, "signal", stop_mult=1.0, target_mult=2.0, friction_pips=friction_pips, pip=PIP)
    td = split_trades(td, daily)
    st_all = compute_stats(td)
    st_final = compute_stats(td[td["split"] == "final"])
    cost_rows.append({
        "friction_pips": friction_pips, "total_R": st_all.get("total_R"),
        "PF": st_all.get("profit_factor"), "final_R": st_final.get("total_R"),
        "final_PF": st_final.get("profit_factor"),
    })
    print(f"  {friction_pips:>4} pip: totalR={st_all.get('total_R', float('nan')):.2f} "
          f"PF={st_all.get('profit_factor', float('nan')):.2f} finalR={st_final.get('total_R', float('nan')):.2f} "
          f"finalPF={st_final.get('profit_factor', float('nan')):.2f}")
pd.DataFrame(cost_rows).to_csv(f"{OUT_DIR}/phase21_cost_sensitivity.csv", index=False)

# ---- concentration ----
res_sorted = resolved.sort_values("r_multiple", ascending=False)
wins = res_sorted[res_sorted["r_multiple"] > 0]
losses = res_sorted[res_sorted["r_multiple"] <= 0]
total_pos = wins["r_multiple"].sum()
total_neg = -losses["r_multiple"].sum()
top10_win_share = wins.head(10)["r_multiple"].sum() / total_pos if total_pos > 0 else np.nan
top10_loss_share = losses.sort_values("r_multiple").head(10)["r_multiple"].sum() / (-total_neg) if total_neg > 0 else np.nan
print(f"\nConcentration: top-10 winners = {top10_win_share:.1%} of gross profit; "
      f"top-10 losers = {abs(top10_loss_share):.1%} of gross loss "
      f"(n_wins={len(wins)}, n_losses={len(losses)})")

# ---- pre-registered rejection check ----
print("\n--- PRE-REGISTERED REJECTION CHECK ---")
reasons = []
if overall.get("profit_factor", 0) < 1.0:
    reasons.append(f"overall PF {overall.get('profit_factor'):.2f} < 1.0")
if split_stats["final"].get("profit_factor", 0) < 1.0:
    reasons.append(f"final PF {split_stats['final'].get('profit_factor'):.2f} < 1.0")
if split_stats["final"].get("total_R", 0) < 0:
    reasons.append(f"final total R {split_stats['final'].get('total_R'):.2f} < 0")
if overall.get("trade_count", 0) < 20:
    reasons.append(f"only {overall.get('trade_count')} total trades < 20")
if not pd.isna(top10_win_share) and top10_win_share > 0.60:
    reasons.append(f"top-10 winners = {top10_win_share:.1%} of gross profit > 60%")

if reasons:
    print("REJECTED. Reasons:")
    for r in reasons:
        print("  -", r)
else:
    print("PASSES pre-registered rejection screen. Proceed to robustness (Phase 22).")
